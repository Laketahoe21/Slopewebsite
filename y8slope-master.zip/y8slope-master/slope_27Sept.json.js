{
"companyName": "Slope",
"productName": "Slope",
"dataUrl": "slope_27Sept.data.unityweb",
"wasmCodeUrl": "slope_27Sept.wasm.code.unityweb",
"wasmFrameworkUrl": "slope_27Sept.wasm.framework.unityweb",
"asmCodeUrl": "slope_27Sept.asm.code.unityweb",
"asmMemoryUrl": "slope_27Sept.asm.memory.unityweb",
"asmFrameworkUrl": "slope_27Sept.asm.framework.unityweb",
"TOTAL_MEMORY": 268435456,
"graphicsAPI": ["WebGL 2.0", "WebGL 1.0"],
"webglContextAttributes": {"preserveDrawingBuffer": false},
"splashScreenStyle": "Dark",
"backgroundColor": "#231F20"
}